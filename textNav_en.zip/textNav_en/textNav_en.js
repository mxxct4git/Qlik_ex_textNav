define( ['jquery', "qlik", "core.utils/deferred", "text!./template.html"],
	function ($, qlik, Deferred, template ) {
		var app = qlik.currApp(); // 直接获取app
		return {
			template: template,
			initialProperties:{
				eventArray: []
			},
			support: {
				snapshot: true,
				export: true,
				exportData: true
			},
			definition: {
				type: "items",
				component: "accordion",
				items: {
					appearance:{
						uses: "settings",
						type : "items",
						items: {
							Text: {
								ref: "text",
								label: "Text",
								type: "string",
								defaultValue: 'Hello World'
							},
							Font:{
								ref: "font",
								label: "Font Settings",
								type: "items",
								items: {
									fontcolor : {
										ref: "fontcolor",
										label:"Font Color",
										type: "string",
										expression: "optional",
										defaultValue: '#1E90FF'
									},
									fontsize: {
										type: "integer",
										label: "Font Size",
										ref: "fontsize",
										defaultValue: 24
									},
									bold: {
										ref: "bold",
										label: "Bold",
										type: "boolean",
										defaultValue: false
									},
									underline: {
										ref: "underline",
										label: "Underline",
										type: "boolean",
										defaultValue: false
									},
									text_align:{
										ref: "text_align",
										label: "Horizontal Position",
										component: "dropdown",
										type: "string",
										options: [{
											value: "left",
											label: "Left"
										},{
											value: "center",
											label: "Center"
										},{
											value: "right",
											label: "Right"
										}]
									},
									line_height:{
										ref: "line_height",
										label: "Vertical Position",
										component: "dropdown",
										type: "string",
										options: [{
											value: "",
											label: "Default"
										},{
											value: "center",
											label: "Center"
										}]
									}
								}
							},
							Border:{
								ref: "border",
								label: "Border Settings",
								type: "items",
								items: {
									border_color : {
										ref: "border_color",
										label:"Border Color",
										type: "string",
										expression: "optional",
										defaultValue: ''
									},
									border_width: {
										ref: "border_width",
										label: "Border Width",
										type: "integer",
										defaultValue: 0
									},
									border_radius: {
										ref: "border_radius",
										label: "Border Radius",
										type: "integer",
										defaultValue: 0
									},
									border_style:{
										ref: "border_style",
										label: "Border Line",
										component: "dropdown",
										type: "string",
										options: [{
											value: "",
											label: "Default"
										},{
											value: "solid",
											label: "Solid"
										},{
											value: "dotted",
											label: "Dotted"
										}]
									}
								}
							},
							Background:{
								ref: "background",
								label:"Background Color",
								type: "string",
								expression: "optional",
								defaultValue: ''
							}
						},
					},
					clickAction:{
						type : "items",
						label : "Navigation",
						items: {
							name: {
								ref: "name",
								label: "Navigation Name",
								type: "string",
								expression: "optional"
							},
							type: {
								ref: "type",
								label: "Navigation Type",
								component: "dropdown",
								type: "string",
								options: [{
									value: "gotosheet",
									label: "Go to a sheet"
								},{
									value: "gotoothersheet",
									label: "Go to other app's sheet"
								},{
									value: "gotowebSite",
									label: "Open a website"
								}]
							},
							sheetID: {
								ref: "sheetID",
								label: "Sheet",
								component: "dropdown",
								type: "string",
								options: function (data) {
									var df = Deferred();

									app.getAppObjectList("sheet", function (reply) {
										var sheetList = reply.qAppObjectList.qItems.map(function (sheet) {
											return {
												value: sheet.qInfo.qId,
												label: sheet.qMeta.title
											}
										});

										df.resolve(sheetList);
									});

									return df.promise;
								},
								show: function (p1, p2, p3) {
									return p1.type == "gotosheet";
								}
							},
							otherAppID: {
								ref: "otherAppID",
								label: "Other app",
								component: "dropdown",
								type: "string",
								options: function (data) {
									var df = Deferred();
									qlik.getGlobal().getAppList(function (items) {
										var appList = items.map(function (item) {
											if(item.qDocId != qlik.currApp().id){
												return {
													value: item.qDocId,
													label: item.qTitle
												}
											}
										});
										df.resolve(appList);
									});
									return df.promise;
								},
								show: function (p1, p2, p3) {
									return p1.type == "gotoothersheet";
								}
							},
							otherAppSheetID:{
								ref: "otherAppSheetID",
								label: "Other app's sheet",
								component: "dropdown",
								type: "string",
								options: function(data, p1,p2){
									var otherApp = qlik.openApp(p1.layout.otherAppID);
									var defer = Deferred();

									otherApp.getAppObjectList("sheet", function (reply) {
										var otherSheetList = reply.qAppObjectList.qItems.map(function (sheet) {
											return {
												value: sheet.qInfo.qId,
												label: sheet.qMeta.title
											}
										});

										defer.resolve(otherSheetList);
									});

									return defer.promise;
								},
								show: function (p1) {
									return p1.type == "gotoothersheet" && p1.otherAppID != "";
								}
							},
							nav_type: {
								ref: "nav_type",
								label: "Navigation Method",
								component: "dropdown",
								type: "string",
								options: [{
									value: "app",
									label: "APP"
								},{
									value: "single",
									label: "Single Object"
								}],
								show: function (p1) {
									return p1.type == "gotoothersheet";
								}
							},
							with_params: {
								ref: "with_params",
								label: "Jump with params",
								type: "boolean",
								defaultValue: false,
								show: function (p1) {
									return p1.type == "gotoothersheet";
								}
							},
							allow_export: {
								ref: "allow_export",
								label: "Allow export data",
								type: "boolean",
								defaultValue: false,
								show: function (p1) {
									return p1.type == "gotoothersheet" && p1.nav_type == "single";
								}
							},
							show_selected: {
								ref: "show_selected",
								label: "Show selections",
								type: "boolean",
								defaultValue: true,
								show: function (p1) {
									return p1.type == "gotoothersheet" && p1.nav_type == "single";
								}
							},
							further_selection: {
								ref: "further_selection",
								label: "Allow further selection",
								type: "boolean",
								defaultValue: false,
								show: function (p1) {
									return p1.type == "gotoothersheet" && p1.nav_type == "single";
								}
							},
							webSite: {
								ref: "webSite",
								label: "Website",
								type: "string",
								defaultValue: '',
								show: function(p1){
									return p1.type == "gotowebSite";
								}
							},
							sameWindow: {
								ref: "sameWindow",
								label: "Open in this window",
								type: "boolean",
								defaultValue: true,
								show: function (p1) {
									return p1.type == "gotowebSite" || p1.type == "gotoothersheet";
								}
							}
						}
					}
				}
			},
			paint: function ($element, layout) {
				let _this = this;
				var width = $element.width();
				var height = $element.height();

				this.$scope.html = layout.text;

				var id = this.$scope.getId(); // 文本id
				var fontcolor = layout.fontcolor;
				var fontsize = layout.fontsize;
				var bold = layout.bold;
				var underline = layout.underline;
				var text_align = layout.text_align;
				var line_height = layout.line_height;

				var border_color = layout.border_color;
				var border_width = layout.border_width;
				var border_radius = layout.border_radius;
				var border_style = layout.border_style;

				var background_color = layout.background;

				var findID = $element.find('#'+id);

				findID.css("width", width*0.9);
				findID.css("height", height*0.8);
				findID.css("margin-left", width*0.1/2);
				findID.css("margin-top", (height - border_width*2)*0.1);

				findID.css("color",fontcolor);
				findID.css("font-size",fontsize);
				findID.css("text-align", text_align);

				if(line_height != ''){
					findID.css("line-height", height*0.8 + 'px');
				}

				if(bold)
				{
					findID.css("font-weight", "bold");
				}else{
					findID.css("font-weight", "normal")
				}

				if(underline)
				{
					findID.css("text-decoration", "underline");
				}else{
					findID.css("text-decoration", "");
				}

				if(border_color != ''){
					findID.css("border-color", border_color);
				}else{
					findID.css("border-color","transparent");
				}

				if(border_width != 0){
					findID.css("border-width", border_width);
				}else{
					findID.css("border-width", '0px');
				}

				if(border_radius != 0){
					findID.css("border-radius", border_radius);
				}else{
					findID.css("border-radius", '0px');
				}

				if(border_style != ''){
					findID.css("border-style", border_style);
				}else{
					findID.css("border-style", "none");
				}

				if(background_color != ''){
					findID.css("background-color",background_color);
				}else{
					findID.css("background-color","transparent");
				}

				this.$scope.selState = app.selectionState();

				return qlik.Promise.resolve();
			},
			controller: ['$scope', function ( $scope ) {
				let generateId = new Date().getTime();
				$scope.getId = function () {
					return generateId;
				};
				$scope.gotoAnywhere = function () {
					var item = $scope.layout;
					if(item.type == 'gotosheet'){
						qlik.navigation.gotoSheet(item.sheetID);
					}else if(item.type == 'gotowebSite'){
						var url = item.webSite.startsWith("http://") || item.webSite.startsWith("https://") ? item.webSite : "http://" + item.webSite;
						if(!item.sameWindow)
							window.open(url, "_blank");
						else
							window.open(url, "_self");
					}else if(item.type == 'gotoothersheet'){
						var url = $scope.get_url(item);
						if(!item.sameWindow)
							window.open(url, "_blank");
						else
							window.open(url, "_self");
					}

				};

				// 跳转其他app下的工作表
				$scope.get_url = function (item) {
					var suffix = "";
					var midsuffix = "&select=clearall"; // single 专用
					var url = "";
					if(item.nav_type == 'app'){
						if(item.with_params){
							// 跳转方式：app 形式 并且 带参传递
							var sel = $(".for_app").text();
							// 清除所有空格
							sel = sel.replace(/\s/g, "");
							//var sel = "管理区/北部, 东南, 水乡;镇区/茶山, 道滘, 莞樟, 黄江, 麻涌;"
							sel = sel.replace(/\s/g, "");
							var str = sel.split(";");
							var len = str.length - 1;
							suffix = "";
							for (var i = 0; i < len; i++) {
								suffix = suffix + "/select/" + str[i].replace(/,/g, ";");
							}

						}else{
							// 跳转方式：app 形式 无参数
						}

						// 2019年9月份本地版本对路径解析问题解决
						otherApp = encodeURI(item.otherAppID);
						if(otherApp.indexOf(":") != -1 ){
							otherApp = otherApp.replace(/:/g, "%3A");
						}
						url = "/sense/app/" + otherApp + "/sheet/" + item.otherAppSheetID + "/options/clearselections";
						if(suffix != ""){
							url += suffix;
						}

					}else if(item.nav_type == 'single'){
						if(item.with_params){
							// 跳转方式：single object 形式 并且 带参传递
							var sel = $(".for_single").text();
							// 清除所有空格
							sel = sel.replace(/\s/g, "");
							// var sel = "管理区, 北部, 东南, 水乡;镇区, 茶山, 道滘, 莞樟, 黄江, 麻涌;"
							sel = sel.replace(/\s/g, "");
							var str = sel.split(";");
							var len = str.length - 1;
							suffix = "";
							for (var i = 0; i < len; i++) {
								suffix = suffix + "&select=" + str[i];
							}
						}else{
							// 跳转方式：single object 形式 无参数
						}

						url = "/single/?appid=" + item.otherAppID + "&sheet=" + item.otherAppSheetID;
						var arr = [];
						if(item.allow_export){
							arr.push("ctxmenu");
						}
						if(item.show_selected){
							arr.push("currsel");
						}
						if(!item.further_selection){
							arr.push("noselections");
						}
						if(arr.length == 0){
							// 没有对应的opt参数选项，直接拼接 midsuffix + suffix
							url = url + midsuffix + suffix;
						}else{
							var opt_str = "&opt=";
							for(var i = 0; i < arr.length; i++){
								if(i != arr.length - 1){
									opt_str += arr[i] + ',';
								}
								else{
									opt_str += arr[i];
								}
							}
							url = url + opt_str + midsuffix + suffix;
						}
					}
					return url;
				}
			}]
		};

	} );

